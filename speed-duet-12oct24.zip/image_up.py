import os
import sys
import requests

def upload_files_to_server(folder_name):
    # Directory containing files to upload
    folder_path = os.path.join(os.getcwd(), folder_name)

    # URL of the PHP script on the server
    upload_url = "http://192.168.68.100/omr_solution/omr/omr_file.php"

    # Iterate over files in the directory
    for filename in os.listdir(folder_path):
        if filename.endswith(('.jpg', '.jpeg', '.png', '.gif')):
            # File path
            file_path = os.path.join(folder_path, filename)
            
            # Send POST request with the file and folder name
            files = {'image': open(file_path, 'rb')}
            data = {'folder_name': folder_name}
            response = requests.post(upload_url, files=files, data=data)
            print(response.text)

if __name__ == "__main__":
    # Check if folder name is provided as command-line argument
    if len(sys.argv) != 2:
        print("Usage: python image_file.py folder_name")
        sys.exit(1)

    folder_name = sys.argv[1]
    upload_files_to_server(folder_name)
