# https://docs.python.org/3/tutorial/modules.html#:~:text=The%20__init__.py,on%20the%20module%20search%20path.
# Use all imports relative to root directory
# (https://chrisyeh96.github.io/2017/08/08/definitive-guide-python-imports.html)
from src.defaults.config import *  # NOQA
from src.defaults.template import *  # NOQA
