#!/bin/bash

get_usd_files(){
	awk -F',' -v src="$2" -v dest="$3" '
	BEGIN { 
		OFS = "," 
	}
	NR==1 {
		# Save the header line and find the indices of 'qr_code' and 'UD'
		for (i=1; i<=NF; i++) {
			gsub(/"/, "", $i);  # Remove double quotes from header
			header[$i] = i;
		}
		qr = header["qr_code"];
		usd = header["usd"];
		fid = header["file_id"];
		
	}
	NR>1 {
		# Remove double quotes from each field
		for (i=1; i<=NF; i++) {
			gsub(/"/, "", $i);
		}
		
		# If the usd field is 1, copy the respective image file from done to inputs directory
		if ($usd == "1") {
			# print "Re-running omr-scanner on: " $fid		
			src_file = src "/" $1
			dest_file = dest "/" $1

			# Copy the file using the system function
			cmd = "cp \"" src_file "\" \"" dest_file "\""
			system(cmd)
		}
	}' "$1"
}



# Source and destination directories
TODO_DIR="todo"
WORK_DIR="inputs"
DONE_DIR="done"
OUTPUT_DIR="outputs"
CSV_DIR="csvs"

# if the directory doesn't exist; create it 
if [ ! -d "$TODO_DIR" ]; then
    mkdir -p "$TODO_DIR"
fi

if [ ! -d "$DONE_DIR" ]; then
    mkdir -p "$DONE_DIR"
fi

if [ ! -d "$CSV_DIR" ]; then
    mkdir -p "$CSV_DIR"
fi

while true; do
	for dir in "$TODO_DIR"/*/; do
		if [ -d "$dir" ]; then
			dir_name=$(basename "$dir")
			mv "$dir" "$WORK_DIR"
			FILE_COUNT=$(find $WORK_DIR/$dir_name -type f | wc -l)
			echo "Processing folder # $dir_name ($FILE_COUNT images) ..."
			python3 main.py > out.txt
			CSVFILE=$(ls $OUTPUT_DIR/$dir_name/Results/Results*)
			

			mkdir -p "$DONE_DIR/$dir_name"
			mv "$WORK_DIR/$dir_name"/* "$DONE_DIR/$dir_name"			
			get_usd_files "$CSVFILE" "$DONE_DIR/$dir_name" "$WORK_DIR/$dir_name"
			
			if [ "$(ls -A $WORK_DIR/$dir_name)" ]; then
				# mogrify -rotate 180 $WORK_DIR/$dir_name/*.png
				FILE_COUNT=$(find $WORK_DIR/$dir_name -type f | wc -l)				
				echo "Re-scanning $FILE_COUNT rotated images ...."
				ls -p "$WORK_DIR/$dir_name" | grep -v /
				python3 main.py > out.txt
				echo "... re-scanning is done;"
				mv "$WORK_DIR/$dir_name"/* "$DONE_DIR/$dir_name"
			fi
			
			rm -rf $WORK_DIR/$dir_name
			

			# python3 image_up.py $DONE_DIR/$dir_name
			# python3 file_up.py $CSVFILE
			cp $CSVFILE $CSV_DIR

			echo "... folder # $dir_name is done."
		fi
	done
	sleep 1  # Check every second
done

