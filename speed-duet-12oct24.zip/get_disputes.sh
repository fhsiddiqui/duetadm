#!/bin/bash

get_disputed_files(){
	awk -F',' -v src="$2" -v dest="$3" '
	BEGIN { 
		OFS = "," 
	}
	NR==1 {
		# Save the header line and find the indices of 'qr_code' and 'UD'
		for (i=1; i<=NF; i++) {
			gsub(/"/, "", $i);  # Remove double quotes from header
			header[$i] = i;
		}
		qr = header["qr_code"];
		ip = header["input_path"];
		
	}
	NR>1 {
		# Remove double quotes from each field
		for (i=1; i<=NF; i++) {
			gsub(/"/, "", $i);
		}
		
		# If the usd field is 1, copy the respective image file from done to inputs directory
		if ($qr == "-1") {
			# print "Re-running omr-scanner on: " $fid		
			src_file = src "/" $1
			dest_file = dest "/" $1

			# Copy the file using the system function
			cmd = "cp \"" src_file "\" \"" dest_file "\""
			system(cmd)
		}
	}' "$1"
}


DISPUTES_DIR="disputes"
DONE_DIR="done"
CSV_DIR="csvs"

# if the directory doesn't exist; create it 
if [ ! -d "$DISPUTES_DIR" ]; then
    mkdir -p "$DISPUTES_DIR"
fi

# Directory containing the CSV files
directory="$CSV_DIR"

# Iterate over each CSV file in the directory
for csv_file in "$directory"/*.csv; do
    # Check if there are no CSV files in the directory
    if [ "$csv_file" == "$directory/*.csv" ]; then
        echo "No CSV files found in the directory."
        break
    fi
	# extract the image directory (ie, room number)
	IMGDIR=${csv_file#*_}
	IMGDIR=${IMGDIR%.csv}
	# echo "$csv_file $DONE_DIR/$IMGDIR $DISPUTES_DIR"
	get_disputed_files "$csv_file" "$DONE_DIR/$IMGDIR" "$DISPUTES_DIR"
done
