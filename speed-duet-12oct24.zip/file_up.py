import sys
import requests

def upload_csv(file_path):
    url = 'http://192.168.68.100/omr_solution/omr/file.php'  # Your Laravel endpoint
    files = {'csv_file': open(file_path, 'rb')}
    response = requests.post(url, files=files)

    try:
        response.raise_for_status()  # Raise an exception for HTTP errors

        # Check if the response contains JSON data
        if response.headers.get('content-type') == 'application/json':
            data = response.json()
            print('Response:', data)
        else:
            print('Response:', response.text)
    except requests.exceptions.HTTPError as err:
        print('HTTP Error:', err)
    except ValueError as err:
        print('Error decoding JSON:', err)
    except Exception as err:
        print('Error:', err)

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python3 file_up.py <file_name.csv>")
        sys.exit(1)
    file_path = sys.argv[1]
    upload_csv(file_path)
